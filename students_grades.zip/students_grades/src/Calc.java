import java.util.ArrayList;

abstract class Calc{
    protected String H1;
    private Student[] students;
    private int totalStudents = 0;

    protected ArrayList<String>  dataNamesTable = new ArrayList<String>();
    protected ArrayList<Integer> dataFrequencyTable = new ArrayList<Integer>();
    protected ArrayList<Integer> sumTable = new ArrayList<Integer>();
    protected ArrayList<Integer> minTable = new ArrayList<Integer>();
    protected ArrayList<Integer> maxTable = new ArrayList<Integer>();
    protected ArrayList<Float> avgTable = new ArrayList<Float>();

    protected Calc(Student[] students){
        setStudents(students);
        setTotalStudents(students.length);
    }
    /*
     * setters
     * */
    private void setTotalStudents(int totalStudents) {
        this.totalStudents = totalStudents;
    }

    private void setStudents(Student[] students) {
        this.students = students;
    }

    /*
     * Getters
     * */

    protected Student[] getStudents() {
        return students;
    }

    /*
     * calc
     * */

    private int getIndex(String name){
        return dataNamesTable.indexOf(name);
    }

    protected void setSumTable(int grade, String name){
        int Index = getIndex(name);
        sumTable.set(Index,sumTable.get(Index) + grade);
    }

    protected void setMinTable(int grade, String name){
        int Index = getIndex(name);
        int min = minTable.get(Index);
        if(minTable.get(Index) == 0){
            minTable.set(Index,grade);
        }else if(grade < min && grade != 0){
            minTable.set(Index,grade);
        }
    }

    protected void setMaxTable(int grade, String name){
        int Index = getIndex(name);
        int max = maxTable.get(Index);
        if(grade > max){
            maxTable.set(Index,grade);
        }
    }

    protected void setFrequencyTableTable(String name){
        int Index = getIndex(name);
        dataFrequencyTable.set(Index,dataFrequencyTable.get(Index) + 1);
    }

    protected void setAvgTable(){
        for (int i = 0; i < dataNamesTable.size(); i++) {
            avgTable.add(Float.valueOf(sumTable.get(i)/dataFrequencyTable.get(i)));
        }
    }

    abstract protected String setName(Student s, Year y,Semester sem, Unit u);

    protected void loopTable(){
        String name;
        for (Student s :
                this.getStudents()) {
            for (Year y :
                    s.getYear()) {
                for (Semester sem :
                        y.getSemester()) {
                    for (Unit u :
                            sem.getUnits()) {
                        name = this.setName(s,y,sem,u);
                        this.setTables(name,u.getGrade());
                    }

                }
            }
        }
        setAvgTable();
    }

    protected void setTables(String str, int grade){
        if(dataNamesTable.contains(str) == false){
            dataNamesTable.add(str);
            this.sumTable.add(grade);
            this.dataFrequencyTable.add(1);
            this.minTable.add(grade);
            this.maxTable.add(grade);
        }else{
            this.setSumTable(grade, str);
            setFrequencyTableTable(str);
            setMinTable(grade, str);
            setMaxTable(grade, str);
        }
    }

    /*
    * Printers
    * */
    abstract protected String getH1();

    private void printHeader(boolean big){
        String h1 = getH1();
        System.out.printf("\n%s\n",h1);
        System.out.printf("%8s"," ");
        for (String s :
                dataNamesTable) {
            if(big == true ){
                System.out.printf("%20s",s);
            }else{
                System.out.printf("%10s",s);
            }
        }
        System.out.print("\n");
    }

    private void printRowData(boolean big,ArrayList table, String type){
        System.out.printf("%8s",type);
        for (Object typeData :
                table) {
            if(typeData instanceof Integer ){
                if(big == true ){
                    System.out.printf("%20d",typeData);
                }else{
                    System.out.printf("%10d",typeData);
                }
            }else{
                if(big == true ){
                    System.out.printf("%20.2f",typeData);
                }else{
                    System.out.printf("%10.2f",typeData);
                }
            }
        }
        System.out.print("\n");
    }

    public void printData(boolean big){
        printHeader(big);

        printRowData(big,minTable , "Min");
        printRowData(big,maxTable , "Max");
        printRowData(big,avgTable , "AVG");
    }
}