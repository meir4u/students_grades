
public class CalcStudents extends Calc{
    private final String H1 = "Students Grades!";

    public CalcStudents(Student[] students){
        super(students);
        setStudents();
        printData(false);
        //this.
    }

    protected String getH1(){
        return this.H1;
    }
    
    public void setStudents() {
        for (Student s :
                this.getStudents()) {
            dataNamesTable.add(s.getName());
            this.sumTable.add((int) s.getSum());
            this.dataFrequencyTable.add(1);
            this.minTable.add(s.getMin());
            this.maxTable.add(s.getMax());
            this.avgTable.add(s.getAvg());
        }
        //setAvgTable();
    }

    protected String setName(Student s, Year y,Semester sem, Unit u){
        return "Students";
    }
}
