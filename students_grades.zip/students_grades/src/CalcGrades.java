abstract class CalcGrades {
    private Float sum = Float.valueOf(0);
    private int min = 0;
    private int max = 0;
    private float avg = 0;
    private int actualUnits = 0;
    boolean calculated = false;

    public CalcGrades(){

    }

    /*
     * calc
     * */
    public void maxGrade(int grade){
        if(this.max < grade && grade != 0){
            this.max = grade;
        }
    }

    public void minGrade(int grade){
        if(this.min == 0){
            this.min = grade;
        }else if(this.min > grade && grade != 0){
            this.min = grade;
        }
    }

    public void avgGradeSet(Integer grade){
        if(grade > 0){
            sum += Float.valueOf(grade);
            actualUnits++;
        }
    }

    public void avgGradeSet(Float grade){
        if(grade > 0){
            sum += grade;
            actualUnits++;
        }
    }
    public abstract void calcData();

    //public abstract void runCalcData();

    /*
    * getters
    * */

    public float getSum() {
        if(calculated == false){
            calcData();
        }
        return sum;
    }

    public int getMin() {
        if(calculated == false){
            calcData();
        }
        return min;
    }

    public int getMax() {
        if(calculated == false){
            calcData();
        }
        return max;
    }

    public float getAvg() {
        if(calculated == false){
            calcData();
        }
        return sum/actualUnits;
    }

    public int getActualUnits() {
        if(calculated == false){
            calcData();
        }
        return actualUnits;
    }
}
