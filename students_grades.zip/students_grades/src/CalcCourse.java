public class CalcCourse extends Calc{
    private final String H1 = "Courses Grades!";

    public CalcCourse(Student[] students){
        super(students);
        loopTable();
        printData(true);
    }

    protected String getH1(){
        return this.H1;
    }

    protected String setName(Student s, Year y,Semester sem, Unit u){
        return u.getName() + " " + y.getnYear() + " " + sem.getName();
    }
}
