import java.util.Random;
import java.util.Scanner;

public class Main {
    private Student[] students;

    public static void main(String[] args) {

        Main start = new Main();
    }

    public Main (){
        System.out.println("program started!");
        Generator g = new Generator();
        this.students = g.getStudents();
        CalcStudents calc = new CalcStudents(this.students);
        CalcTeacher calcT = new CalcTeacher(this.students);
        CalcUnit calcU = new CalcUnit(this.students);
        CalcCourse calcC = new CalcCourse(this.students);
        CalcTotalGrades calcTotal = new CalcTotalGrades(this.students);
        //calc.printCourseGrades();
    }


}
