public class Year extends CalcGrades{
    private static final int NUMBER_OF_SEMESTERS = 3;
    private Semester[] semesters;
    private int nYear;

    public Year(){
        setSemester();
    }

    public void setnYear(int nYear) {
        this.nYear = nYear;
    }

    private void setSemester() {
        this.semesters = new Semester[NUMBER_OF_SEMESTERS];
        for (int i = 0; i < NUMBER_OF_SEMESTERS; i++) {
            semesters[i] = new Semester();
        }
    }

    public Semester[] getSemester() {
        return semesters;
    }

    public int getnYear() {
        return nYear;
    }

    public void calcData(){
        for (Semester s:
                semesters) {
            s.calcData();
            this.maxGrade(s.getMax());
            this.minGrade(s.getMin());
            this.avgGradeSet(s.getAvg());
        }
    }
}
