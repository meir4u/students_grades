public class Student extends CalcGrades{
    private Year[] year;
    private String name;
    private int[] units;


    public Student(String name){
        this.name = name;
        setYear();
    }

    /*
    * calc data
    * */

    public void calcData(){
        calculated = true;
        for (Year y:
                year) {
            y.calcData();
            this.maxGrade(y.getMax());
            this.minGrade(y.getMin());
            this.avgGradeSet(y.getAvg());
        }
    }

    /*
    * setters
    * */
    private void setYear() {
        this.year = new Year[3];
        for (int i = 0; i < 3; i++) {
            year[i] = new Year();
        }
    }

    public void setName(String name) { this.name = name; }

    /*
    * getters
    * */
    public Year[] getYear() { return year; }

    public String getName() {
        return name;
    }

    public int getTotalUnits(){
        return this.year[0].getSemester()[0].getUnits().length;
    }

}
