import java.util.Random;

public class Generator{
    private Student[] students;

    public Generator (){
        setStudents(10);
        setYears(2003,3);
        setSemesters();
        setUnits();
        setGrades(15,100);
        //this.printUnitsGrades();
    }

    public Student[] getStudents() {
        return students;
    }

    public void setStudents(int total) {
        this.students = new Student[total];
        for (int i = 0; i < total; i++) {
            students[i] = new Student("name " + i);
        }
    }
    public void setYears(int startYear,int total){
        for (Student s :
                this.students) {
            for (int j = 0; j < total; j++) {
                s.getYear()[j].setnYear(startYear+j);
            }
        }
    }

    public void setSemesters(){
        String[] semester = new String[3];
        semester[0] = "SUMMER";
        semester[1] = "AUTUMN";
        semester[2] = "WINTER";
        for (Student s :
                this.students) {
            for (Year y :
                    s.getYear()) {
                for (int i = 0; i < 3; i++) {
                    y.getSemester()[i].setName(semester[i]);
                }
            }
        }
    }

    public  void setUnits(){
        for (Student s :
                this.students) {
            for (Year y :
                    s.getYear()) {
                for (Semester sem :
                        y.getSemester()) {
                    int i=0;
                    for (Unit u :
                            sem.getUnits()) {
                        u.setName("unit " + i++ );
                        u.setTeacherName("teacher " + i++ );
                    }

                }
            }
        }
    }

    private int getRandom(int max, int min){
        Random rand = new Random();
        int randomNum;

        if((rand.nextInt((2 - 0) + 1) + 0) == 0){
            randomNum = 0;
        }else if((rand.nextInt((10 - 1) + 1) + 1) > 4) {
            randomNum = rand.nextInt((max - 50) + 1) + 50;
        }else{
            randomNum = rand.nextInt((max - min) + 1) + min;
        }

        return randomNum;
    }

    public void setGrades(int min, int max){
        int randomNum1;
        int randomNum2;

        for (Student s :
                this.students) {
            for (Year y :
                    s.getYear()) {
                for (Semester sem :
                        y.getSemester()) {
                    for (Unit u :
                            sem.getUnits()) {

                        /*to add more random zeros*/
                        randomNum1 = getRandom(max, min);
                        randomNum2 = getRandom(max, min);
                        u.setGrade(randomNum1,randomNum2);
                    }
                }
            }
        }
    }

    public void printHeaderStudents(){
        System.out.printf("%8s"," ");
        for (Student s :
                this.students) {
            System.out.printf("%10s",s.getName());
        }
        System.out.print("\n");
    }
    /*
    public void printUnitsGrades(){
        printHeaderStudents();
        for (int i = 0; i < students[0].getYear()[0].getSemester()[0].getActualUnits(); i++) {
            System.out.printf("%8s",students[0].getYear()[0].getSemester()[0].getUnits()[i].getName());

        }
    }
    */

}

