
public class CalcUnit extends Calc{
    private final String H1 = "Unit Grades!";

    public CalcUnit(Student[] students){
        super(students);
        loopTable();
        printData(false);
    }

    protected String getH1(){
        return this.H1;
    }


    protected String setName(Student s, Year y,Semester sem, Unit u){
        return u.getName();
    }



}