public class CalcTotalGrades extends Calc {
    private final String H1 = "Total Grades!";

    public CalcTotalGrades(Student[] students){
        super(students);
        loopTable();
        printData(true);
    }

    protected String getH1(){
        return this.H1;
    }

    protected String setName(Student s, Year y,Semester sem, Unit u){
        return "Total";
    }
}
